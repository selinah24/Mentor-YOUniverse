# MentorYOUniverse
The code is in the src\main\java\com\example\mentor_youniverse

You’re a star in this galaxy. You, your peers, and your potential mentors/mentees are light years away from each other! But no matter how far you guys are, Mentor YOUniverse will bring you all together

Spectra 4.0 Hackathon Submission [VENUS]
Focus on underrepresented genders community
Name: Mentor YOUniverse
Match underrepresented genders mentors and mentees
Show vague location
Categories: academic, profession/career, mental, life decisions
Galaxy = Main page
Orbit = Matches and Chat functions


Collaborated with Selina Huynh
